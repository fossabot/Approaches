var express = require('express');
var app = express();
var path = require('path');
var router = express.Router();
var bodyParser = require('body-parser');
var pkg = require('./package');

// session所需要的模块，注意加载顺序
var flash = require('connect-flash');
var session = require('express-session');
const MongoStore = require('connect-mongo')(session);
var config = require('./config/default')


// 路由
var routes = require('./routes')
// var index = require('./routes/index');
// var register = require('./routes/register');
// var register_suc = require('./routes/registersucess');

//mongoose连接数据库
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/loginDemoDB');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    console.log('数据库连接成功了')
});

// 模版引擎
app.set('view engine', 'ejs');
// 静态文件
app.use(express.static(path.join(__dirname,'public')))

app.use(bodyParser.urlencoded({ extended: true }));
// 模版目录
app.set('views',path.join(__dirname,'views'))

// app.use('/',index)

// app.use('/register', register);
// app.use('/register_sucess', register_suc);

app.use(session({
  name: config.session.key, // 设置 cookie 保存 session id 
  secret: config.session.secret, // 设置 secret 来计算 hash 值并放在 cookie 中，使产生的 signedCookie 防篡改
  resave: true, // 强制更新 session
  saveUninitialized: false, // 强制创建一个 session
  cookie: {
    maxAge: config.session.maxAge// 过期后 cookie 中的 session id 自动删除
  },
  store: new MongoStore({// 将 session 存储到 mongodb
    url: config.mongodb
  })
}));


app.use(flash());

//保存在全局变量success,error
app.use(function (req, res, next) {
  res.locals.user = req.session.user
  res.locals.success = req.flash('success').toString()
  res.locals.successOut = req.flash('successOut').toString()
  res.locals.error = req.flash('error').toString()
  next()
})


// 设置模板全局常量
app.locals.blog = {
  name: pkg.name,
  description: pkg.description
}



// 挂载路由
routes(app)

app.listen(config.port,function(){
    console.log('The server listening in port '+config.port)
})