module.exports = {
    port: 3001,
    session: {
      secret: 'loginDemo',
      key: 'loginDemo',
      maxAge: 2592000000
    },
    mongodb: 'mongodb://localhost:27017/loginDemoDB'
  }