// var express = require('express');
// var router = express.Router();

// /* GET home page. */
// router.get('/', function(req, res) {
//     res.render('index', { title: '后台登录' });
// });


module.exports = function (app) {
	app.get('/', function(req, res) {
		res.render('index', { title: 'Login' });
	 })
	 app.use('/login', require('./login'))
	 app.use('/register', require('./register'))
	app.use('/register_sucess', require('./registersucess'))
	app.use('/signout', require('./signout'))
	

	app.use(function (req, res) {
		if (!res.headersSent) {
			res.status(404).render('404')
		}
	})
    
	// 404 page
	// app.use(function (req, res) {
	// 	if (!res.headersSent) {
	// 		res.status(404).render('404')
	// 	}
	// })
}
