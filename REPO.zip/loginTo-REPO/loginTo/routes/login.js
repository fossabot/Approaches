var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var user = require('../models/user');
// var checkNotLogin = require('../models/checkLogin').checkNotLogin;
/*导入node的加密库*/
var crypto = require('crypto');



router.get('/',function(req,res){
    res.render('login', {title: 'Login sucess', readonly:'readonly'})
})

router.post('/',function(req,res){
    var name = req.body.user.name;
    var password = req.body.user.password;
    console.log('登录名字'+name)
    if(password===''&&name===''){
        req.flash('error', '用户名或密码不能为空')
        return res.redirect('back')
     }

 user.findOne({name:name,password:password},function(err,doc){
 if(!doc){
     
    req.flash('error', '用户名或密码错误')
    return res.redirect('back')

//     res.render('login',{
//         title:'登录成功',
//         name:name,
//         password:password,
//         readonly:'readonly'
//     }
//     // ,function(err,html){
//     //     req.flash('success', '登录成功')
//     //     res.send(html);
//     // }
// )
 }else{


    req.flash('success', '登录成功')

    req.session.user = req.body.user
    // req.session.user.readonly = 'readonly'
    res.redirect('/login')
 }

        })
    
})

module.exports = router;