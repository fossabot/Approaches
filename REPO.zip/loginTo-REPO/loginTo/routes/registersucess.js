var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var user = require('../models/user');
/*导入node的加密库*/
var crypto = require('crypto');

router.get('/',function(req,res){

    res.render('register_sucess', {title: 'Register Sucess', readonly:'readonly'});

})

router.post('/', function(req, res) {
    // var md5 = crypto.createHash('md5');
    var name = req.body.user.name;
    var password = req.body.user.password;
    if(name==='' && name.length<=0 && password==='' && password.length<=0){
        req.flash('error','用户名或密码不能为空')
        //res.render('register.ejs', {title: 'Register', name: '', password: '',readonly:'read-write'});
        return res.redirect('back')
    }else {
        /*MD5加密密码*/
        // md5.update(password + name);
      //  var pwd = md5.digest('base64');//将加密后的md5密码使用base64加密
        //使用findOne查询数据库中是否存在相同的用户名，如果存在则提示更换用户名，否则将内容写入数据库
        user.findOne({name: name}, function (err, doc) {
            if (err) return next(err);
            //查询数据库是否有相同的用户名，假如存在则提示注册失败
            if (doc) {
                req.flash('error','用户名已经存在，请更换')
                //res.render('register.ejs', {title: 'Register', name: '', password: '',readonly:'read-write'});
                return res.redirect('back')

            } else {
                 user.create({ // 创建一组user对象置入model
                    name: name,
                    password: password
                }, function (err, doc) {
                    if (err) {
                        res.send(500);
                        console.log(err);
                    } else {
                        req.session.user = req.body.user
                        req.flash('success','注册成功')
                        res.redirect('register_sucess');
                        //res.send(200);
                    }
                });
            }
        })
    }
});


module.exports = router;