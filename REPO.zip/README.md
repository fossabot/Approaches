* [Dos与Git常用与自制‘栗子’](https://github.com/tgqnanman/Approaches-To-Learning/blob/master/Dos%20%26%20Gitbash.md)

* [Git Bash版本控制学习](https://github.com/tgqnanman/Approaches-To-Learning/blob/master/git%20bash%E4%B8%8Egh-pages%E9%A2%84%E8%A7%88.md)

* [markdown学习](https://github.com/tgqnanman/Approaches-To-Learning/blob/master/Markdown.md)

* [chrome调试](https://github.com/tgqnanman/Approaches-To-Learning/blob/master/Chrome.md)



