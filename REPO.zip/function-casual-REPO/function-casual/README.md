# function-casual
- [固定表头](https://htmlpreview.github.io/?https://github.com/tgqnanman/function-casual/blob/gh-pages/%E5%9B%BA%E5%AE%9A%E8%A1%A8%E5%A4%B4%E6%8F%92%E4%BB%B6%E7%B3%BB%E5%88%97/index.html)

