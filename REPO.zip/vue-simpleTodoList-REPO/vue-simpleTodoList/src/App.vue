<template>
  <section>
    <h2>TodoList</h2>
    <input class="addInput" 
      placeholder="to do something" 
      v-model="newTodo"
      @keyup.enter="addOneTodo">
    <section>
      <ul class="todo-list">
        <li v-for="todo in todos" 
          :key="todo.id"
          :class="{ completed: todo.completed }"
          @click="completeTodo(todo)">
          {{ todo.id + ' - ' + todo.title }}
          <button class="deleteBtn" @click="removeTodo(todo)">x</button>
        </li>
      </ul>
    </section>
  </section>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      todos: [{
        id: 0,
        title: 'value',
        completed: false
      }],
      newTodo: '',
      id: 1
    }
  },
  methods: {
    addOneTodo: function() {
      const value = this.newTodo;
      if (!value){
        return;
      }
      this.todos.push({
        id: this.id++,
        title: value,
        completed: false
      }),
      this.newTodo = ''
    },
    removeTodo: function(todo) {
      this.todos.splice(this.todos.indexOf(todo),1)
    },
    completeTodo: function(todo) {
      const todoIndex = this.todos.indexOf(todo);
      this.todos[todoIndex].completed = !this.todos[todoIndex].completed;    }
  }
}
</script>

<style lang="scss">
.completed{
  text-decoration: line-through;
}
.deleteBtn{
    background-color: red;
  color: white;
  border: none;
  border-radius: 3px;
  font-size: 12px;
  margin-left: 20px;
}

li{
  list-style: none;
  margin-top: 10px;
}
</style>
