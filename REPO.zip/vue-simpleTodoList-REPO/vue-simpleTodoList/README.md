<<<<<<< HEAD
# my-todolist

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).
=======
# vue-simpleTodoList
>>>>>>> ec133c1136a0ba8c20bc8b650c4b2aa85f9cd13a
