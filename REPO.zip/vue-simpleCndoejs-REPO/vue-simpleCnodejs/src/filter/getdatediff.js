// function curDateTime(dateTimeStamp){
//   var d = new Date(dateTimeStamp);
//   var currentYear = new Date().getFullYear();
//   var year = d.getFullYear();
//   var month = d.getMonth()+1;
//   var date = d.getDate();
//   var day = d.getDay();
//   var hours = d.getHours();
//   var minutes = d.getMinutes();
//   // var seconds = d.getSeconds();
//   var ms = d.getMilliseconds();
//   if(currentYear != year){
//     var curDateTime = year + "-";
//   }else{
//     var curDateTime = '';
//   }
//   if(month > 9)
//    curDateTime = curDateTime + month;
//   else
//    curDateTime = curDateTime + "0" + month;
//   if(date > 9)
//    curDateTime = curDateTime + "-" + date;
//   else
//    curDateTime = curDateTime + "-0"+ date;
//   if(hours > 9)
//    curDateTime = curDateTime + " "+ hours;
//   else
//    curDateTime = curDateTime + " 0"+ hours;
//   if(minutes > 9)
//    curDateTime = curDateTime + ":"+ minutes;
//   else
//    curDateTime = curDateTime + ":0" + minutes;
//   return curDateTime;
//   }

//   function getMonthDays(dateTimeStamp) {
//     var date = new Date(dateTimeStamp);
//     var Y = date.getFullYear();
//     var M = date.getMonth()+1;
//     var days = new Date(Y,M,0).getDate();
//     return days*1;
//   }

// // dateTimeStamp 15位
// export function getDateDiff(dateTimeStamp){
// 	var minute = 1000 * 60;
// 	var hour = minute * 60;
// 	var day = hour * 24;
// 	var halfamonth = day * 15;
// 	var month = day * getMonthDays(dateTimeStamp*1);
// 	var now = new Date().getTime();
// 	var diffValue = now - dateTimeStamp;
// 	if(diffValue < 0){return;}
// 	var monthC = diffValue / month;
// 	var weekC = diffValue / (7*day);
// 	var dayC = diffValue / day;
// 	var hourC = diffValue / hour;
// 	var minC = diffValue / minute;
// 	if(8 <= dayC){
//     result = "" + curDateTime(dateTimeStamp*1);
//   }
// 	else if(168 <= hourC && hourC < 192){
// 		result = "" + parseInt(weekC) + "周前";
//   }
// 	else if(48 <= hourC && hourC < 168){
// 		result = ""+ parseInt(dayC) + "天前";
//   }
//   else if(24 <= hourC && hourC < 48){
// 		result = "昨天";
// 	}
// 	else if(1 <= hourC && hourC < 24){
// 		result = "" + parseInt(hourC) + "小时前";
// 	}
// 	else if(1 <= minC && minC  < 60){
// 		result = "" + parseInt(minC) + "分钟前";
//   }
//   else if(365 <= dayC){
// 		result = "" + curDateTime(dateTimeStamp*1);
// 	}else
// 	result = "刚刚";
// 	return result;
// }



 function aa(val){
  console.log(val)

}

const filters = {
  aa
}

export function registerFilters (Vue) {
  Object.keys(filters).forEach((key) => {
    Vue.filter(key, filters[key])
  })
}
