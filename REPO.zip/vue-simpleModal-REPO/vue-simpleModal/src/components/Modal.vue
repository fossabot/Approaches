<template>
  <!-- 添加过渡效果 -->
  <transition name="fade">
    <!-- <div class="modal-back" @click="close"> -->
    <div class="modal-back" v-show="visibleComProps" @click="close">
        <div class="modal" @click.stop>
          <div class="modal-header">
          <button type="button" class="btn-close" @click="close">X</button>
          </div>
          <div class="modal-body">
            <!-- 由父组件的data传值到子组件Modal.vue的tips值 -->
            {{ tipsModal }}
          </div>
        </div>
    </div>
  </transition>
</template>

<script>
export default {
    name: 'Modal',
    props: {
      visibleComProps: {
        type: Boolean,
        default: false      
        },
      //父组件通过:tips="tipsApp" 子组件的prpos定义
      tipsModal: ''  
    },
    methods: {
      close(){
          //子组件传值到父组件
          this.$emit('close',false); 
      }
    }
}
</script>

<style lang="scss" scoped>
  body{
    /* 简单初始 */
    margin: 0;
    padding: 0;
  }
  .modal-back{
    position: fixed;
    width: 100%;
    height: 100%;
    top:0;
    left: 0;
    /* 透明罩 */
    background-color: #808080;
    opacity: .5;
    /* flex布局，水平垂直居中 */
    display: flex;
    justify-content: center;
    align-items: center;
    .modal{
      display: flex;
      box-shadow: 2px 2px 20px;
      background-color: #fff;
      flex-direction: column;
      margin-top: -100px;
      width: 16rem;
      height: 10rem;
        .btn-close{
          // 叉叉按钮样式
          background-color: #0b9eda;
          color: white;
          border: none;
          border-radius: 50%;
          font-size: 20px;
        }
        .modal-header,.modal-footer{
          padding: 10px;
        }
        .modal-body{
          padding: 20px 10px;
        }
        .btn-close{
          float:right;
        }
    }
  }
    // 根据文档的组件过渡，添加transition
    .fade-enter-active, .fade-leave-active {
      transition: opacity .5s;
    }
    .fade-enter, .fade-leave-to{
      opacity: 0;
    }
</style>



