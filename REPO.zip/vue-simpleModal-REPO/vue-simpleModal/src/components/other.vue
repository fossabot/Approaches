<template>
  <section>
    <h3>Question:</h3>
    <p>{{ question }}</p>
    <input v-model="question">
    <h3>Answer:</h3>
    <p>{{ answer }}</p>
  </section>
</template>

<script>
export default {
  name: 'Other',
  data() {
    return {
    question: '',
    answer: ''    
    }
  },
  created: function(){
    this.afterAnswer();
  },
  watch: {
    question: function(){
      this.answer = "Waiting for answer......"
      this.afterAnswer()
    }
  },

  methods: {
    getAnswer(){
      if(this.question.trim() === ''){
        this.answer = 'Please enter your question...';
        return        
      }
      else if(this.question.indexOf('?') === -1){
        this.answer = 'Wtf, no answer';
        // pass value to App.vue
        this.$emit('otherComEmit','NoAnswer'); 
        return
      }
      this.$emit('otherComEmit','Correct'); 
      this.answer = 123;
    },
    afterAnswer(){
      setTimeout(this.getAnswer, 1000)
    }
  }
}
</script>
