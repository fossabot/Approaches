<template>
  <div id="app" v-loading="loading">
  <!-- 直接传个true进去show好了 -->
  <button type="button" class="btn-open" @click="change(true)">打开模态框</button>
  <!-- 父组件向子组件传参，子组件:visible="visible"，前一是子组件props声明，后一是父组件data声明 -->
  <Modal v-model="visibleAppData" @close="change" :visibleComProps="visibleAppData" :tipsModal="tipsApp"/> 
  <Other @otherComEmit="otherApp" />  
  </div>
</template>

<script>
import Modal from './components/Modal.vue'
import Other from './components/other.vue'
export default {
  name: 'app',
  components: {
      Modal,
      Other
  },
  data () {
    return {
      visibleAppData: false,
      tipsApp: 'Please enter your question ?',
      loading: true    
    }
  },
  beforeCreate: function(){
    this.loading = true;
  },
  created: function(){
    this.loading = false;
  },
  methods: {
    change(val){
      this.visibleAppData = val;
    },
    otherApp(val){
      if(val=='NoAnswer'){
        this.change(true);
        this.tipsApp = 'I\'m sorry, no answer~~'
        console.log('other.vue: '+val)
      }else if(val=='Correct'){
        this.change(true);
        this.tipsApp = 'You are right!!!'
      }
 
    }
  }
}
</script>


<style lang="scss" scoped>
.btn-open{
  background-color: skyblue;
  color: white;
  border: none;
  border-radius: 3px;
  font-size: 20px;
}
</style>
